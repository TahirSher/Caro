# Claims audit (generated; edit the rules, never the verdicts)

| id | claim | verdict |
|---|---|---|
| H1 | CAMPO raises simulated customer affect over SFT | supported |
| H2 | CAMPO keeps information, hygiene and monitor (non-inferior) and length (equivalent) vs SFT | supported |
| campo_no_pessimism | H3a: pessimism contributes | not supported: no detectable contribution |
| campo_no_moments | H3b: the moment constraints keep length and information | not supported: the ablation also meets the constraints |
| campo_no_trust | H3c: the trust regions contribute | not supported: no detectable contribution |
| campo_no_select | H3d: selection + certification costs no affect beyond its guarantee | not supported: selection costs affect |
| H4_online_dpo | Pareto: CAMPO vs online_dpo | Pareto-incomparable: online_dpo has a higher outcome but violates ['hygiene', 'log_words'] |
| H4_offline_dpo | Pareto: CAMPO vs offline_dpo | Pareto-incomparable: offline_dpo has a higher outcome but violates ['hygiene'] |
| H4_sft_bon | Pareto: CAMPO vs sft_bon | not supported |
| H4_sentiment_only | Pareto: CAMPO vs sentiment_only | supported (higher outcome, constraints met) |
| H5a | the gain replicates with an out-of-family customer and an unseen emotion classifier | supported |
| H5b | humans prefer CAMPO over SFT on satisfaction | untested |
| H5c | the judge ranks alternative replies to the SAME context as humans do | untested (needs the human study) |
| H5c_automatic | two independent automatic evaluators agree on within-context rankings above chance | supported |
| judge_partial_anchor | the judge tracks the next-turn human emotion beyond the current emotion | supported |
| H6 | no returned CAMPO policy is significantly worse than SFT on any objective (test split) | supported |
| certified_improvement | CAMPO certified an improvement in every seed | not supported (1 of 3 seeds returned SFT) |
